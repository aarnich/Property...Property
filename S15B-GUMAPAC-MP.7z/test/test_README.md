# This folder is purely for unit testing numerical-like functions
### edit testMain.c and run the test executable in order to run unit tests